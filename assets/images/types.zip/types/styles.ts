export type Colours = "primary" | "secondary" | "white" | "black"
