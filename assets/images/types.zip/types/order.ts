export type OrderType = "delivery" | "takeout"

export type Order = {
    id: string
    guest: boolean
    customer: any
    accountid: string
    completed: boolean
    created: Date
    items: OrderItem[]
    supplier: OrderSupplier
}

export type OrderItem = {
    dealid: number
    productid: number
    name: string
    qty: number
    price: number
    total: number
}

export type OrderSupplier = {
    supplierid: string
    name: string
}
