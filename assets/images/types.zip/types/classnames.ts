import classNames from "classnames"

export const cn = classNames
