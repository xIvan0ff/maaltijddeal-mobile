import { Image } from "utils/types"
import { LatLng } from "./latlng"
import { Review } from "./review"
import { WorkingHour } from "./workingHour"

export type Restaurant = {
    id: string
    name: string
    description: string
    address: string
    postCode: string
    city: string
    website: string
    email: string
    phone: string
    fax: string

    logo: Image
    rating: number
    ratingCount: number
    reviews: Review[]
    location: LatLng
    category: string[]
    workingHours: WorkingHour[]

    deliveryPrice?: number
    freeDeliveryOrderAmount: number
    minimumOrderAmount: number

    delivery: boolean
    takeout: boolean
}
