export type Review = {
    id: string
    dealId: string
    restaurantId: string
    score: number
    comment: string
    name: string
    dateCreated: string
    visible: boolean
}
