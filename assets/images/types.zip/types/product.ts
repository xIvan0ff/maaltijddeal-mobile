import { Category } from "./category"
import { Restaurant } from "./restaurant"

export type ProductState = "open" | "close" | "openInAnHour"

export type Product = {
    id: number
    title: string
    description?: string
    price: number
    restaurant: Restaurant
    reviews?: number
    image?: string
    rating?: number
    oldPrice?: number
    discount?: number
    // Refactoring day
    dealOptions: any[]
    dealExtras: any
    category?: Category

    state: ProductState
}
