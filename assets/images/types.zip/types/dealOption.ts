export type DealOption = {
    id: number
    dealId: number
    restaurantId: number
    name: string
    text: string
    price: number
}

export type DealExtra = {
    id: number
    restaurantId: number
    name: string
    text: string
    categoryName: string
    price: number
    dealId: number
}
