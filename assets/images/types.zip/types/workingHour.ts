export type WorkingHour = {
  weekday: number
  openTime: string
  closeTime: string
  closedAllDay: boolean
}
