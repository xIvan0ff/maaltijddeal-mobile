import { DealExtra, DealOption } from "./dealOption"
import { OrderType } from "./order"
import { Product } from "./product"
import { Restaurant } from "./restaurant"

export type CartItemData = {
    dealId: number
    productId: number
    quantity: number
    name: string
    price: number
    regularPrice: number
    totalPrice: number
    totalDiscount: number
    orderType: OrderType
}

export type CartItemOption = {
    dealOption: DealOption
    quantity: number
}

export type CartItemExtra = {
    dealExtra: DealExtra
    quantity: number
}

export type CartItemDeal = {
    deal: Product
    quantity: number
}

export type RestaurantCartData = {
    cartItemDealsOptions: {
        cartItemDeal: CartItemDeal
        options: CartItemOption[]
        extras: CartItemExtra[]
    }[]

    note: string

    restaurant: Restaurant
}

export type CartData = {
    restaurants: {
        [key: number]: RestaurantCartData
    }
    paymentFee?: number
    version: number
}
